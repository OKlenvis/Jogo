import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:math';

void main() {
  runApp(GameWidget(game: JumperGame()));
}

class JumperGame extends FlameGame with HasKeyboardHandlerComponents, HasCollisionDetection {
  late Player player;
  double score = 0;

  @override
  Color backgroundColor() => const Color(0xFF111111);

  @override
  Future<void> onLoad() async {
    // Adiciona o jogador
    player = Player();
    add(player);

    // Cria as plataformas iniciais
    for (int i = 0; i < 5; i++) {
      add(Platform(Vector2(Random().nextDouble() * size.x, i * 150.0)));
    }
  }

  @override
  void update(double dt) {
    super.update(dt);
    // Sistema de câmera simples: a "câmera" sobe se o player subir muito
    if (player.position.y < size.y / 2) {
      double diff = (size.y / 2) - player.position.y;
      player.position.y = size.y / 2;
      
      // Move todos os componentes para baixo para simular a subida
      for (var component in children.whereType<Platform>()) {
        component.position.y += diff;
        // Se a plataforma sumir embaixo, respawna ela em cima
        if (component.position.y > size.y) {
          component.position.y = 0;
          component.position.x = Random().nextDouble() * size.x;
        }
      }
    }
  }
}

class Player extends RectangleComponent with KeyboardHandler, HasGameRef<JumperGame>, CollisionCallbacks {
  double velocityY = 0;
  double gravity = 800;
  double jumpForce = -500;
  double speed = 400;
  int horizontalDir = 0;

  Player() : super(
    size: Vector2(40, 40), 
    paint: Paint()..color = Colors.cyanAccent,
    anchor: Anchor.center
  );

  @override
  void update(double dt) {
    super.update(dt);

    // Gravidade
    velocityY += gravity * dt;
    position.y += velocityY * dt;

    // Movimento Lateral
    position.x += horizontalDir * speed * dt;

    // Loop de tela lateral (teletransporte)
    if (position.x < 0) position.x = gameRef.size.x;
    if (position.x > gameRef.size.x) position.x = 0;

    // Reset se cair
    if (position.y > gameRef.size.y) {
      position = gameRef.size / 2;
      velocityY = 0;
    }
  }

  @override
  bool onKeyEvent(KeyEvent event, Set<LogicalKeyboardKey> keysPressed) {
    horizontalDir = 0;
    if (keysPressed.contains(LogicalKeyboardKey.keyA)) horizontalDir = -1;
    if (keysPressed.contains(LogicalKeyboardKey.keyD)) horizontalDir = 1;
    return true;
  }

  // Lógica de pulo ao colidir com a plataforma
  void jump() {
    if (velocityY > 0) { // Só pula se estiver caindo
      velocityY = jumpForce;
    }
  }
}

class Platform extends RectangleComponent with HasGameRef<JumperGame>, CollisionCallbacks {
  Platform(Vector2 pos) : super(
    position: pos,
    size: Vector2(80, 15),
    paint: Paint()..color = Colors.greenAccent,
    anchor: Anchor.center
  );

  @override
  void update(double dt) {
    super.update(dt);
    // Checa colisão manualmente para simplificar
    final player = gameRef.player;
    if (player.velocityY > 0 && 
        player.toRect().overlaps(this.toRect()) && 
        player.position.y < position.y) {
      player.jump();
    }
  }
}